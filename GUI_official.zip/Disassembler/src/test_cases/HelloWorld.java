package test_cases;

public class HelloWorld {
	public static void main(String[] args) {
		int x=0;
		if(x>10){
			System.out.println(x);
		}
		
	}
}
