package program_proper;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MainClass extends JPanel {
		//JavaToAssembly test = new JavaToAssembly("HelloWorld.java");
		private static final String HOME = "home";
		private static final String TOASM = "toasm";
		private static final String TOJAVA = "tojava";
		private CardLayout cardlayout = new CardLayout();
		private JPanel mainPanel = new JPanel(cardlayout);
		private Home homePanel = new Home();
		private toAsm asmPanel = new toAsm();
		private toJava javaPanel = new toJava();
	public MainClass() {
		mainPanel.add(homePanel.getMainComponent(), HOME);
		mainPanel.add(asmPanel.getMainComponent(), TOASM);
		mainPanel.add(javaPanel.getMainComponent(), TOJAVA);
		
		homePanel.addToAsmBtnActionListener(new ActionListener() {
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            cardlayout.show(mainPanel, TOASM);
	         }
	      });
		
		homePanel.addToJavaBtnActionListener(new ActionListener() {
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            cardlayout.show(mainPanel, TOJAVA);
	         }
	      });
		
		asmPanel.addBackBtnActionListener(new ActionListener() {
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            cardlayout.show(mainPanel, HOME);
	         }
	      });
		javaPanel.addBackBtnActionListener(new ActionListener() {
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            cardlayout.show(mainPanel, HOME);
	         }
	      });
	}
	private JComponent getMainComponent() {
	      return mainPanel;
	 }
	  private static void createAndShowUI() {
	      JFrame frame = new JFrame("Assembler/Disassembler");
	      
	      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	     // ImageIcon img = new ImageIcon("pictures/fish.png");
	     // frame.setIconImage(img.getImage());
	    //  frame.setUndecorated(true);
			
			
			/*try{
				UIManager.removeAuxiliaryLookAndFeel(UIManager.getLookAndFeel());
				SyntheticaLookAndFeel.setWindowsDecorated(false);
				UIManager.setLookAndFeel(new AcrylLookAndFeel()	);
				//UIManager.setLookAndFeel(new SyntheticaClassyLookAndFeel());
				//UIManager.setLookAndFeel(new SyntheticaAluOxideLookAndFeel());
				SwingUtilities.updateComponentTreeUI(frame);
				}catch (Exception e){
					e.printStackTrace();
				}*/
		   // frame.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
	        frame.getContentPane().add(new MainClass().getMainComponent());
		   // frame.pack();
		    frame.setSize(700, 525);
	        frame.setResizable(false);
	        frame.setVisible(true);
	        frame.setLocationRelativeTo(null);
	   }
		
	public static void main(String[] args) {
		 createAndShowUI();
		/*java.awt.EventQueue.invokeLater(new Runnable() {
	         public void run() {
	            createAndShowUI();
	         }
	      });*/
	}
}
