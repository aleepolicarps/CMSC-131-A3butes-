package assembler;

public class MainClass {
	public static void main(String[] args){
		AssemblyToJava asm = new AssemblyToJava("skeleton.asm");
	}
}
