package assembler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class AssemblyToJava {
	
	
	private ArrayList<String> code = new ArrayList<String>();
	private ArrayList<String> stringVar = new ArrayList<String>();
	private ArrayList<String> intVar = new ArrayList<String>();
	private ArrayList<String> mainCode = new ArrayList<String>();
	
	public AssemblyToJava(String fileName){
		loadFile(fileName);
		getVariables();
	}
	private void loadFile(String fileName){
		File file = new File(fileName);
		BufferedReader reader = null;
		try{
			reader = new BufferedReader(new FileReader(file));
			String source = reader.readLine();
			while(source!=null){
				source=source.replace("\n", "");
				source=source.replace("\t", "");
				code.add(source);
				source = reader.readLine();
			}
			reader.close();
		}
		catch(FileNotFoundException e){
			System.out.println("File not found.");
		}
		catch(IOException e){
			System.out.println("Error");
		}
	}
	private void getVariables(){
		boolean onDataBlock = false;
		ArrayList<String> varDeclarations = new ArrayList<String>();
		for(String line:code){
			if(onDataBlock && line.contains(".")){
				break;
			}
			if(line.equals(".data")){
				onDataBlock = true;
			}
			else if(onDataBlock){
				varDeclarations.add(line);
			}
		}
		//removes extra empty line
		varDeclarations.remove("");
		
		for(String line:varDeclarations){
			if(line.contains("\"")){
				String[] splitLine;
				splitLine = line.split(" db ");
				stringVar.add(splitLine[0]);
				String temp = splitLine[1];
				temp = temp.substring(1);
				temp = "\"" + temp.substring(0, temp.indexOf("\"")+1);
				stringVar.add(temp);
			}
			else{
				String[] splitLine;
				if(line.contains(" db "))
					splitLine = line.split(" db ");
				else
					splitLine = line.split(" dw ");
				if(splitLine[1].matches("[0-9]+")){
					intVar.add(splitLine[0]);
					intVar.add(splitLine[1]);
				}
			}
		}
		for(String line:intVar){
			System.out.println(line);
		}
	}
}
