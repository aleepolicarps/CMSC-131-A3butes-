public class Skeleton {
public static void main(String[] args){
int var1 = 0;
int var6 = 65533;
int var7 = 9;
String var2 = "hello";
String var3 = "haha";
String var4 = "hoho";
String var5 = "Hello world! Merry Christmas";
int ax = 0;
int bx = 0;
int cx = 0;
int dx = 0;
int al = 0;
int ah = 0;
int bl = 0;
int bh = 0;
int cl = 0;
int ch = 0;
int dl = 0;
int dh = 0;
if(var7==al){
System.out.print(var5);
}
if(ah==0){
System.out.print(var5);
}
else{
System.out.print("a");
}
do{
System.out.print("a");
cx++;
}while(!(cx>10));
while(cx<0){
cx++;
ax=0*3;
}
ah=0;
al=al+bl;
ah=ah-0;
cx--;
cx++;
System.out.print("a");
System.out.print("<");
System.out.print("\n");
System.out.print(var5);
System.out.print(var4);
al=203*4;
ah=203%4;
}
}
