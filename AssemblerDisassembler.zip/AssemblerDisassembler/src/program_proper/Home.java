package program_proper;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Home {
	private JPanel mainPanel = new JPanel();
	private JButton toAsm, toJava;
	public Home() {
		ImageIcon bg = new ImageIcon("pictures/main.gif");
		JLabel background = new JLabel(bg);
		
		toAsm = new JButton();
		toAsm.setBorderPainted(false); 
		toAsm.setContentAreaFilled(false); 
		toAsm.setFocusPainted(false); 
		toAsm.setBounds(95, 140, 145, 200);
		background.add(toAsm);
		
		toJava = new JButton();
		toJava.setBorderPainted(false); 
		toJava.setContentAreaFilled(false); 
		toJava.setFocusPainted(false); 
		toJava.setBounds(445, 140, 165, 200);
		background.add(toJava);
		
		mainPanel.add(background);
	}
	
	public void addToAsmBtnActionListener(ActionListener listener) {
		toAsm.addActionListener(listener);
	}
	
	public void addToJavaBtnActionListener(ActionListener listener) {
		toJava.addActionListener(listener);
	}
	public JComponent getMainComponent() {
		 return mainPanel;
	}
}
