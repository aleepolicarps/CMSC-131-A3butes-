package program_proper;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class toAsm {
	private JPanel mainPanel = new JPanel();
	private JButton convert, back;
	private JTextField field, text;
	private JLabel label, error, success, background;
	public toAsm(){
		ImageIcon bg = new ImageIcon("pictures/toAsm.gif");
		background = new JLabel(bg);
		
		convert = new JButton("Convert");
		convert.setBounds(440, 150, 80, 30);
		background.add(convert);
		
		back = new JButton();
		back.setBorderPainted(false); 
		back.setContentAreaFilled(false); 
		back.setFocusPainted(false); 
		back.setBounds(30, 40, 120, 30);
		background.add(back);
		
		label = new JLabel("Enter filename: ");
		label.setBounds(120,110,200,30);
		background.add(label);
		
		field = new JTextField();
		field.setOpaque(false);
		field.setBorder(null);
		field.setBounds(160,140,270,65);
		background.add(field);
		
		text=new JTextField();
		text.setOpaque(false);
		text.setBorder(null);
		text.setEditable(false);
		text.setFont(new Font("Arial", Font.BOLD, 16));
		text.setBounds(250,70,250,50);
		background.add(text);
		convert.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		if(e.getSource()==convert){
	    			String fileName = field.getText();
	    			File file = new File(fileName);
	    			BufferedReader reader = null;
	    			if(fileName.contains(".java")){
		    			try{
		    				reader = new BufferedReader(new FileReader(file));
		    				reader.close();
		    				JavaToAssembly test = new JavaToAssembly(fileName);
		    				text.setText("File successfully converted");
		    			}
		    			catch(FileNotFoundException f){
		    				text.setText("File not found");
		    			}
		    			catch(IOException f){
		    				text.setText("IOException.");
		    			}
	    			}
	    			else
	    				text.setText("Please enter a .java file.");
	    		}
	    	}
		});		
		mainPanel.add(background);
	}
	
	public void addBackBtnActionListener(ActionListener listener) {
		back.addActionListener(listener);
	}
	public JComponent getMainComponent() {
		 return mainPanel;
	}
}
