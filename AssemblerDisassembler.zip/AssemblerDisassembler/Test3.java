class Test3
{
    public static void main(String[] args)
    {
        int z;
        int a = 10, b = 5;
        for (z = 0; z < 10; z++)
        {
            a += b;
            System.out.println(a);
        }
    }
}