public class AssemblySample {
public static void main(String[] args){
int krizia = 18;
int eva = 999;
int x = 1;
int z = 10;
String alee = "hi bh3";
int ax = 0;
int bx = 0;
int cx = 0;
int dx = 0;
int al = 0;
int ah = 0;
int bl = 0;
int bh = 0;
int cl = 0;
int ch = 0;
int dl = 0;
int dh = 0;
if(x>10){
System.out.print(alee);
}
else{
System.out.print(eva);
}
}
}
