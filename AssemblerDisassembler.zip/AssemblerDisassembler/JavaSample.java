public class Helloworld {
public static void main(String[] args){
	int krizia = 18;
	int eva = 999;
	int x = 1;
	int z = 10;
	String alee = "hi bh3";
		while(x>10){
			System.out.print(alee);
			System.out.print(eva);
		}
		if(krizia==18)
			System.out.print(krizia);
		else
			System.out.print(alee);
}
}
