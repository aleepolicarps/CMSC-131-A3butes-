public class Test2 {
public static void main(String[] args){
int x = 9;
int y = 100;
int z = 0;
int ax = 0;
int bx = 0;
int cx = 0;
int dx = 0;
int al = 0;
int ah = 0;
int bl = 0;
int bh = 0;
int cl = 0;
int ch = 0;
int dl = 0;
int dh = 0;
ah=x;
ah=ah+y;
z=ah;
if(z>=0){
// prepare for printing
x=x+'0';
System.out.print(x);
}
else{
if(z!=0){
// prepare for printing
z=z+'0';
System.out.print(z);
}
else{
}
}
}
}
