public class Test1 {
public static void main(String[] args){
String message = "The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart.";
String message2 = "I can't change the direction of the wind, but I can adjust my sails to always reach my destination.\n";
int ax = 0;
int bx = 0;
int cx = 0;
int dx = 0;
int al = 0;
int ah = 0;
int bl = 0;
int bh = 0;
int cl = 0;
int ch = 0;
int dl = 0;
int dh = 0;
System.out.print(message);
System.out.print(message2);
}
}
